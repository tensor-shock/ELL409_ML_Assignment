part=$2
shift 2

python part${part}.py ${@}
